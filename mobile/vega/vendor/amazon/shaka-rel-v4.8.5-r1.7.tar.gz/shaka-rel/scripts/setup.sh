#!/usr/bin/env bash

set -e 

export VERSION="4.8.5"
echo "Shaka dist script for $VERSION"
echo ""

# Check prerequisites
echo "Checking prerequisites..."

# Check Git
if ! command -v git &> /dev/null; then
    echo "Error: Git is not installed. Please install Git v1.9+ and try again."
    exit 1
fi
echo "✓ Git found: $(git --version)"

# Check Python3
PYTHON_CMD=""
if command -v python3 &> /dev/null; then
    PYTHON_CMD="python3"
    echo "✓ Python3 found: $(python3 --version)"
elif command -v python &> /dev/null; then
    PYTHON_VERSION=$(python --version 2>&1 | grep -oE '[0-9]+' | head -1)
    if [ "$PYTHON_VERSION" -ge 3 ]; then
        PYTHON_CMD="python"
        echo "✓ Python found: $(python --version)"
    else
        echo "Error: Python 3.5+ is required. Found Python 2.x"
        exit 1
    fi
else
    echo "Error: Python is not installed. Please install Python v3.5+ and try again."
    exit 1
fi

# Check Java
if ! command -v java &> /dev/null; then
    echo "Error: Java is not installed. Please install Java Runtime Environment v21+ and try again."
    exit 1
fi
echo "✓ Java found: $(java -version 2>&1 | head -1)"

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "Error: Node.js is not installed. Please install Node.js v18+ and try again."
    exit 1
fi
NODE_VERSION=$(node --version | grep -oE '[0-9]+' | head -1)
if [ "$NODE_VERSION" -lt 16 ]; then
    echo "Warning: Node.js version is below 16. Recommended: v18+ (or v16.20.2 for glibc compatibility)"
fi
echo "✓ Node.js found: $(node --version)"

# Check npm
if ! command -v npm &> /dev/null; then
    echo "Error: npm is not installed. Please install npm and try again."
    exit 1
fi
echo "✓ npm found: $(npm --version)"

echo ""

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SHAKA_REL_DIR="$(dirname "$SCRIPT_DIR")"
PATCHES_DIR="$SHAKA_REL_DIR/shaka-patch"

# Verify patches directory exists
if [ ! -d "$PATCHES_DIR" ]; then
    echo "Error: Patches directory not found at $PATCHES_DIR"
    echo "Please ensure you extracted the package correctly"
    exit 1
fi
echo "Found patches directory: $PATCHES_DIR"

# Change to scripts directory
cd "$SCRIPT_DIR"

# Clean up existing directory if present
if [ -d "shaka-player" ]; then
    echo "Removing existing shaka-player directory..."
    rm -rf shaka-player
fi

# Clone shaka repo
echo "Cloning shaka-player repository..."
git clone https://github.com/shaka-project/shaka-player.git
cd shaka-player

# Checkout branch from $VERSION tag
echo "Checking out version $VERSION..."
git checkout -b amz_$VERSION v$VERSION

# Apply patches
echo "Applying patches..."
git am "$PATCHES_DIR"/*.patch -3

# Build shaka
echo "Building shaka-player..."
$PYTHON_CMD build/all.py

echo "Build completed successfully!"
